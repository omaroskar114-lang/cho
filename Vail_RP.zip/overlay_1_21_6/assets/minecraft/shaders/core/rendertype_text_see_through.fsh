#version 330

#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    // VAIL: подложка ника (чёрная, прозрачность 25%) рисуется этим же шейдером — не рисуем её
    if (vertexColor.r < 0.02 && vertexColor.g < 0.02 && vertexColor.b < 0.02 && vertexColor.a > 0.2 && vertexColor.a < 0.3) {
        discard;
    }
    vec4 color = texture(Sampler0, texCoord0) * vertexColor;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = color * ColorModulator;
}