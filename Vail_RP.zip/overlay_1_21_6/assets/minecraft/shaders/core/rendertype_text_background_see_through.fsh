#version 150

// VAIL: убирает тёмную подложку под ником игрока (фон «see-through» текста над головой).
// Сам ник рисуется другим шейдером и остаётся видимым.

in vec4 vertexColor;

out vec4 fragColor;

void main() {
    discard;
}