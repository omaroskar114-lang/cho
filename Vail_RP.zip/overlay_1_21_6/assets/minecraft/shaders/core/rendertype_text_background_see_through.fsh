#version 330

#moj_import <minecraft:dynamictransforms.glsl>

// VAIL: убирает тёмную подложку под ником игрока (фон текста над головой).
// Сам ник рисуется другим шейдером и остаётся видимым.

in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor * ColorModulator;
    if (color.a < 2.0) {
        discard;
    }
    fragColor = color;
}