#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    // VAIL: стандартная подложка ника (чёрная, прозрачность 25%) не рисуется. Цветные фоны голограмм остаются.
    if (vertexColor.r < 0.02 && vertexColor.g < 0.02 && vertexColor.b < 0.02 && vertexColor.a > 0.2 && vertexColor.a < 0.3) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}